package com.example.move;

import android.app.Activity;

public class MainActivity3 extends Activity {

}
